		       Mp3Wrap v. 0.5

 Copyright (c) 2002 M. Trotta - <matteo.trotta@lib.unimib.it>

   Visit http://mp3wrap.sourceforge.net for latest realease!

DISCLAIMER

This software comes with absolutely no warranty, and is intended
only to help people handling mp3 files. Author despises any use
of mp3 technology for illegal purposes and will not be rensposible
for any illegal action you can do with this software (if there are).

LICENSE INFORMATION

You can redistribute this software and/or modify it under the
terms of the GNU Library General Public License as published
by the Free Software Foundation; either version 2 of the License,
or (at your option) any later version.

This software is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Library General Public License for more details.

You should have received a copy of the GNU Library General Public
License along with this library; if not, write to the
Free Software Foundation, Inc., 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.

See COPYING for more details.

HELP INFORMATION

Read INSTALL to see help on how to install this program.

Run program without arguments to view HELP informations.

Author will be pleased to receive any comments, bugs,
advices and new functions to add to this program.

NOTE: This program is closely linked to Mp3Splt. So the best thing is to have both:

	Mp3Splt: http://mp3splt.sourceforge.net
	Mp3Wrap: http://mp3wrap.sourceforge.net

Enjoy!

Matteo Trotta  - <matteo.trotta@lib.unimib.it>

